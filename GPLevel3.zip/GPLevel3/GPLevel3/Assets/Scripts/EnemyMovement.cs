﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum MovementState
{
    EnemyIdle,//0
    EnemyWalk,//1
    EnemyJump//2
}
public class EnemyMovement : MonoBehaviour
{


    protected Rigidbody2D body;
    public Vector2 JumpForce = new Vector2(0, 5);
    
    protected bool isOnJumpingSurface = false;
    public float movementSpeed = 5;

    Vector2 customVelocity;
    EnemyData data;

    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        data = GetComponent<EnemyData>();
    }
   

   

   
}
