﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BouncyEnemy : MonoBehaviour {

    Rigidbody2D body;
    public Vector2 Direction = new Vector2(1, 0);
    public float Speed = 3;
    SpriteRenderer sprite;
    public float Rotation = 2;
    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
    }


    void Update()
    {
        body.velocity = new Vector2(Direction.x * Speed, body.velocity.y);
       


    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Bounce")
        {
            Direction *= -1;
            sprite.flipX = !sprite.flipX;
        }
    }
}
