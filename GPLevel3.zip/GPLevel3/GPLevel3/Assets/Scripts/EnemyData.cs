﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyData : MonoBehaviour
{
    public MovementState State;
    public MovementState previousState;

    Animator animator;

    Vector3 checkpointPosition;
    void Start()
    {
        animator = GetComponent<Animator>();


    }

    void Update()
    {
        if (State != previousState)
        {
            animator.SetInteger("State", (int)State);
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            SetState(MovementState.EnemyIdle);
        }
        else if (Input.GetKeyDown(KeyCode.W))
        {
            SetState(MovementState.EnemyJump);
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            SetState(MovementState.EnemyWalk);
        }

    }

    public void SetState(MovementState newState)
    {
        if (newState != State)
        {
            previousState = State;
            State = newState;
        }
    }

}
