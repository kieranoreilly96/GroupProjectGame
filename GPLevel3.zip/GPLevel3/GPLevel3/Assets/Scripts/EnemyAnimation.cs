﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemyAnimation : MonoBehaviour
{
    EnemyData data;
    EnemyMovement movement;
    Animator animator;
    SpriteRenderer sprite;

    void Start()
    {
        data = GetComponent<EnemyData>();
        movement = GetComponent<EnemyMovement>();
        animator = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        //only update animation when the player state has changed
        if (data.State != data.previousState)
        {
            animator.SetInteger("State", (int)data.State);
            data.previousState = data.State;
        }

        
    }
}
