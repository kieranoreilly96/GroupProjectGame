﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpriteController : MonoBehaviour
{
    private PlayerMovement movement;
    private SpriteRenderer sprite;

    void Start()
    {
        movement = GetComponent<PlayerMovement>();
        sprite = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (movement.direction < 0)
        {
            sprite.flipX = true;
        }
        else if (movement.direction > 0)
        {
            sprite.flipX = false;
        }
    }
}
